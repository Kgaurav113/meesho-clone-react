export const IsAuth="IsAuth";
export const StoreNum="StoreNum";
export const ShowLogin="ShowLogin";