export const CurrCart ="CurrCart";
export const Updatedtotal="Updatedtotal"
export const Marginadd="Marginadd"
export const Addressdata="Addressdata"
export const HideNavbar="HideNavbar"